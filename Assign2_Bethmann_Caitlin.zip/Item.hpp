#ifndef Item_HPP
#define Item_HPP
#include <string>

using namespace std;

class Item {

	private:
		string Item_Name;
		string Item_Unit;
		int Item_Quantity;
		int Item_Price;
		int ExtPrice;
	public:
		Item();
		Item(string Name, string Unit, int Quant, int Price);
		bool operator == (const Item& rhs);
		void SetName(string Name);
		string GetName();
		void SetUnit(string Unit);
		string GetUnit();
		void SetQuantity(int Quant);
		int GetQuantity();
		void SetPrice(int Price);
		int GetPrice();
		int CalcExtPrice();

};

#endif
