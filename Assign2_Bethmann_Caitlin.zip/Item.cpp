/**********
 * Author: Caitlin Bethmann
 * Date: 6/19/17
 * Description: Item holds the name, unit, quantity, and price of an item. Also calculates the extended price of an item.
 ************/ 

#include "Item.hpp"
#include <iostream> 
#include <string>

using namespace std;

Item::Item(){ //default constructor
	Item_Name = "Cereal";
	Item_Unit = "box";
	Item_Quantity = 1;
	Item_Price = 2;
}

Item::Item(string Name, string Unit, int Quant, int Price){ //constructor
	this->Item_Name = Name;
	this->Item_Unit = Unit;
	this->Item_Quantity = Quant;
	this->Item_Price = Price;

}

bool Item::operator==(const Item& rhs){
	if(this->Item_Name==rhs.Item_Name){
		return true;
	}
	return false;
}

void Item::SetName(string Name){
	this->Item_Name = Name;
}

string Item::GetName(){
	return Item_Name;
}

void Item::SetUnit(string Unit){
	this->Item_Unit = Unit;
}

string Item::GetUnit(){
	return Item_Unit;
}

void Item::SetQuantity(int Quant){
	this->Item_Quantity = Quant;
}

int Item::GetQuantity(){
	return Item_Quantity;
}

void Item::SetPrice(int Price){
	this->Item_Price = Price;
}

int Item::GetPrice(){
	return Item_Price;
}

int Item::CalcExtPrice(){
	this->ExtPrice = (Item_Quantity * Item_Price);
	return ExtPrice;
}
