/************
 * Author: Caitlin Bethmann
 * Date: 6/19/17
 * Description: The list stores the item objects. It has the capacity to hold 4 items but has a resize function if there are more than 4 items. It adds items, removes items, and displays information on each item as well as the total price of all the items in the list.
 ***********/

#include "List.hpp"
#include <iostream>
#include <cstdlib>

using namespace std;

void checker(istream& stream, int check){
	if(stream.fail()){
		cout << "ERROR: Only numerical inputs. " << endl;
		stream.clear();
		exit(EXIT_FAILURE);
	}else if (check < 0){
		cout << "ERROR: Not a valid integer. " << endl;
		exit(EXIT_FAILURE);
	}else {
		return;
	}
}



List::List(){
	MyArray = new Item[4];
	Size = 0; //setting starting size of list to zero
	Capacity = 4; //setting capacity of list to 4

}
List::~List(){
	delete[] MyArray; //prevent memory leaks
}

void List::AddItem(){
	string Name;
	string Unit;
	int Quant;
	int Price;

	cout << "Enter the item name: " << endl;
	cin >> Name;

	cout << "Enter unit of your item (box, can, pounds, ounces): " << endl;
	cin >> Unit;
	
	cout << "Enter how many you would like to purchase: " << endl;
	cin >> Quant;
	checker(cin, Quant);

	cout << "Enter the unit price: " << endl;
	cin >> Price;
	checker(cin, Price);

	Item food = Item(Name, Unit, Quant, Price);

	for (int i = 0; i < Size; ++i){
              if (MyArray[i] == food){
			int update;
			cout << "Item is already on the list" << endl;
			cout << "Would you like to update this item? (choose 1 for yes/choose 2 for no) " << endl;
			cin >> update;
			if (update == 2){
				return;
			}
		}
	}
			
		

	if (Size == Capacity){	
		Capacity += 4; //Capacity increased by 4
		Item*MyArray2 = new Item[Capacity];//creating temporary new array to resize
		for (int i = 0; i < Size; i++){
			MyArray2[i] = MyArray[i];
		}
		MyArray = MyArray2;
	}
	MyArray[Size++] = Item(Name, Unit, Quant, Price);
	
}

void List::RemoveItem(){
	string Name;

	cout << "Please enter the name of the item you would like to remove: " << endl;
	cin >> Name;

	for (int i = 0; i < Size; ++i){
		if (MyArray[i].GetName() == Name){
			if (Size > (i+1)){
				for (int x = i; x < Size-1; x++){
					MyArray[x] = MyArray[x + 1];
				}
			}
			Size--;
		}

	}
}	

void List::Display(){
	int Total = 0;
	
	for (int i = 0; i < Size; ++i){ //works its way through all the items in the list
		cout << "Item Name: " << MyArray[i].GetName() << endl;
		cout << "Item Unit: " << MyArray[i].GetUnit() << endl;
		cout << "Item Quantity: " << MyArray[i].GetQuantity() << endl;
		cout << "Item Price: " << MyArray[i].GetPrice() << endl;
		cout << "Extended Price: " << MyArray[i].CalcExtPrice() << endl;
		Total += (MyArray[i].GetPrice() * MyArray[i].GetQuantity());//adding up total price of all items times their quantities
	}
	cout << "Total Price of all items: " << Total << endl;
}
