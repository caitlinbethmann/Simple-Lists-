/**********
 * Author: Caitlin Bethmann
 * Date: 7/19/17
 * Description: Program shows menu to customer. Options are to add or remove an item, display the list, and leave the program. Program creates a shopping list based on the users input.
 * ************/

#include "Item.hpp"
#include "List.hpp"
#include <iostream>

using namespace std;

void showMenu();

int main(){

	int Choice;
	List Shopping1;

	cout << "Hello valued customer! Welcome back to the Grocery Store!" << endl;

	do{
		showMenu();

		cin >> Choice;

		switch (Choice){
			case 1:
				{	
					Shopping1.AddItem();
					break;
				}

			case 2:
				{
					Shopping1.RemoveItem();
					break;
				}

			case 3:
				{
					cout << "Here are the current items in your shopping list: " << endl;
					Shopping1.Display();
					break;
				}

			case 4:
				{
					cout << "Thanks for shopping! Bye! " << endl;
					break;
				}

			case 5:
				{
					cout << "Your input is invalid. Please choose option 1-4: " << endl;
					break;
				}
		}

	}while(Choice!=4);

	return 0;

}

void showMenu(){
		cout << "\n";
		cout << "What would you like to do: " << endl;
                cout << "Enter 1 to add an item:" << endl;
                cout << "Enter 2 to remove an item: " << endl;
                cout << "Enter 3 to view your shopping list report: " << endl;
                cout << "Enter 4 to exit shopping program: " << endl;
}
