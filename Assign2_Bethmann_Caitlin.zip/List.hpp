#ifndef List_HPP
#define List_HPP
#include "Item.hpp"

class List{
	private: 
		Item* MyArray;
		int Size;
		int Capacity;
	public:
		List();
		~List();
		void AddItem();//increase size of array in this function if necessary 
		void RemoveItem();
		void Display();
};

#endif
